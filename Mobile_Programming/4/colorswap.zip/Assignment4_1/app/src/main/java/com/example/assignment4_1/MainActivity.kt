package com.example.assignment4_1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment4_1.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        Creating an action when we click the button
        binding.button.setOnClickListener {
//            Randomly generating R value among RGB
            val R = Random().nextInt(256)
//            Randomly generating G value among RGB
            val G = Random().nextInt(256)
//            Randomly generating B value among RGB
            val B = Random().nextInt(256)
//            Setting color fo the textView
            binding.textView.setTextColor(Color.rgb(R,G,B))
//            Changing value of text
            binding.textView.text = "COLOR: ${R}r ${G}g ${B}b"
        }
    }
}