package com.example.assignment4_2

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment4_2.databinding.ActivityContactBinding

class ContactActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact)

        //        Initializing binding
        val binding = ActivityContactBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        If clicking my email, moving to gmail app to write email to my email address
        binding.email.setOnClickListener {
//            Passing my email address
            val uri = Uri.parse("mailto:jeewoncoding@gmail.com")
            val emailIntent = Intent(Intent.ACTION_SENDTO, uri)
            startActivity(emailIntent)
        }

//        If clicking my phone number, moving to dial and my number coming up
        binding.phonenum.setOnClickListener{
            val calling = Intent(Intent.ACTION_DIAL).apply{
//                Passing my phone number
                data = Uri.parse("tel:01037179132")
            }
            startActivity(calling)
        }

//        If clicking my instagram id, moving to my instagram
        binding.instaid.setOnClickListener {
//            Passing my instagram id
            val instaIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/jeewonkimm/"))
            startActivity(instaIntent)
        }


    }
}