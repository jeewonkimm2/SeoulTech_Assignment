package com.example.assignment4_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment4_2.databinding.ActivityContactBinding
import com.example.assignment4_2.databinding.ActivityEducationBinding

class EducationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_education)

        //        Initializing binding
        val binding = ActivityEducationBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}