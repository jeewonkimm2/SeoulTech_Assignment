package com.example.assignment4_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment4_2.databinding.ActivityContactBinding
import com.example.assignment4_2.databinding.ActivityExperienceBinding

class ExperienceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_experience)

        //        Initializing binding
        val binding = ActivityExperienceBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}