package com.example.assignment4_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.assignment4_2.databinding.ActivityContactBinding
import com.example.assignment4_2.databinding.ActivityHobbyBinding

class HobbyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hobby)

        //        Initializing binding
        val binding = ActivityHobbyBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}