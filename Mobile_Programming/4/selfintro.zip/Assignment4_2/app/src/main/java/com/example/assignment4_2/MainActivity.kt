package com.example.assignment4_2

import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.assignment4_2.databinding.ActivityMainBinding
//Main page of the app
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        Initializing binding
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        If clicking github icon, moving to github
        binding.github.setOnClickListener{
            val gitIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/jeewonkimm2"))
            startActivity(gitIntent)
        }

//        If clicking linkedin icon, moving to linkedin
        binding.linkedin.setOnClickListener{
            val linkedinIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/jeewon-kim-06056a236/"))
            startActivity(linkedinIntent)
        }

//        If clicking contact icon, moving to detailed screen, ContactActivity view
        binding.contact.setOnClickListener{
            val contactIntent = Intent(this,ContactActivity::class.java)
            startActivity(contactIntent)
        }

//        If clicking click me button, dialog comes up asking if you wanna know more about me
        binding.clickme.setOnClickListener {
            AlertDialog.Builder(this)
//                    Dialog Title
                .setTitle("Do you wanna know more about me?")
//                    If clicking yes, moving to SubActivity view
                .setPositiveButton("Yes", DialogInterface.OnClickListener {dialog,which->
                    val subIntent = Intent(this, SubActivity::class.java)
                    startActivity(subIntent)
                })
//                    If clicking no, toast comes up
                .setNegativeButton("No",DialogInterface.OnClickListener{
                    dialog,which -> Toast.makeText(this, "Staying here", Toast.LENGTH_SHORT).show()
                }).show()

        }
    }
}