package com.example.assignment4_2


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.view.menu.MenuView
import androidx.recyclerview.widget.RecyclerView
import com.example.assignment4_2.databinding.ActivityContactBinding
import com.example.assignment4_2.databinding.ActivitySubBinding

class SubActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sub)

//        Initializing binding
        val binding = ActivitySubBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        Making a data for spinner
        val spinList = listOf("Choose a topic", "Education", "Experience", "Hobby")
//        Initializing an adapter for spinner
        val spinAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,spinList)
        binding.spinner.adapter = spinAdapter

//        Initializing each intent
        val eduIntent = Intent(this,EducationActivity::class.java)
        val exIntent = Intent(this,ExperienceActivity::class.java)
        val hoIntent = Intent(this,HobbyActivity::class.java)

//        Initializing actions for each selection
        binding.spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                If clicking education, moving to education page
                if(p2==1){
                    startActivity(eduIntent)
                }
//                If clicking experience, moving to experience page
                if(p2==2){
                    startActivity(exIntent)
                }
//                If clicking hobby, moving to hobby page
                if(p2==3){
                    startActivity(hoIntent)
                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }





    }
}

