package com.example.myapplication5

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.myapplication5.databinding.ActivityMainBinding

//Creating MainActivity
class MainActivity : AppCompatActivity() {
//    Launching and receiving data from SubActivity named 'message'
    val requestLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
//            Showing Toast dialog with the message received
            Toast.makeText(this, it.data?.getStringExtra("message"), Toast.LENGTH_SHORT).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        initializing binding and assigning to the binding variable
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

//        Interacting with other activity via clicking button
        binding.button.setOnClickListener {
//            Implicit intent generation : ACTION_DIAL
            val calling = Intent(Intent.ACTION_DIAL)
//                    Changing text(phone number) value
                .apply{
                    val inputNum = binding.editTextTextPersonName.text
                    intent.putExtra("inputNum", "$inputNum")
                    data = Uri.parse("tel:${inputNum}")
                }.run{
//                    To choose application, creating a chooser
                    Intent.createChooser(this,"Which app to use?")
                }
//            Launching activity
            requestLauncher.launch(calling)
        }
        
    }
}