package com.example.myapplication5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication5.databinding.ActivitySubBinding

//Creating SubActivity
class SubActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivitySubBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        Getting data and split the data
        var phoneNum = intent.data.toString().substring(4,)
//        Sending data to MainActivity
        intent.putExtra("message","You can't call to $phoneNum!!!!")
//        Callee action result is okay
        setResult(RESULT_OK, intent)
//        Finishing SubActivity
        finish()
    }
}